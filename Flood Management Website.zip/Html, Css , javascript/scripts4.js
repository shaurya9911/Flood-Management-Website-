document.getElementById('alert-form').addEventListener('submit', function (event) {
    event.preventDefault();

    // Getting user data
    const email = document.getElementById('email').value;
    const location = document.getElementById('location').value;

    if (email && location) {
        alert(`Thank you for subscribing, ${email}! You will receive flood alerts for ${location}.`);
        // Here, you would integrate a backend service to handle the subscription logic
        // Example: send data to server, save in database, etc.
    } else {
        alert('Please fill in all fields before submitting.');
    }
});
