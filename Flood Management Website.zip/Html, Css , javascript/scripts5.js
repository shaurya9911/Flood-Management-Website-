document.getElementById('volunteer-form').addEventListener('submit', function (event) {
    event.preventDefault();

    // Get user input
    const name = document.getElementById('name').value;
    const email = document.getElementById('email').value;
    const location = document.getElementById('location').value;
    const skills = document.getElementById('skills').value;

    // Validate form fields
    if (name && email && location && skills) {
        alert(`Thank you, ${name}! Your volunteer application has been submitted. We'll get in touch soon at ${email}.`);
        // In a real-world scenario, you would send this data to a backend server for processing.
    } else {
        alert('Please fill out all fields before submitting.');
    }
});
