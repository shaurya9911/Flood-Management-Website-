// Handle the form submission (e.g., show a confirmation message or send via an API)
document.getElementById('contact-form').addEventListener('submit', function(event) {
    event.preventDefault();
    alert("Thank you for contacting us! We'll get back to you shortly.");
    // Here you could send the form data to your server or an email API
});
